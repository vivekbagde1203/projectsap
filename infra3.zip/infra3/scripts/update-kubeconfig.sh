#!/bin/bash
set -e

#CLUSTER_NAME=$(terraform -chdir=../ output -raw eks_cluster_name)
#REGION=$(terraform -chdir=../ output -raw region)

CLUSTER_NAME=my-eks
REGION=ap-south-1
PROFILE=test

echo "Updating kubeconfig for cluster: $CLUSTER_NAME in $REGION..."
aws eks update-kubeconfig --name "$CLUSTER_NAME" --region "$REGION" --profile "$PROFILE"

kubectl get nodes -o wide

