#!/bin/bash
set -e

kubectl delete daemonset aws-node -n kube-system || true
kubectl delete clusterrole aws-node || true
kubectl delete clusterrolebinding aws-node -n kube-system || true
kubectl delete serviceaccount aws-node -n kube-system || true

